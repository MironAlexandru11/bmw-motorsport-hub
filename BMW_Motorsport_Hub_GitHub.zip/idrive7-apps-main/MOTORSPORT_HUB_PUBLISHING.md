# Publishing Motorsport Hub to your MGU Store

1. Download `idrive7-apps-with-motorsport-hub.zip` and extract it on your computer.
2. Create a new GitHub repository (public or private, depending on your MGU Store access).
3. Upload the **contents** of the extracted `idrive7-apps-main` folder to the repository root. The root must contain `mgu-repo.json`, `apps/`, and `kit/`.
4. Confirm `apps/motorsport_hub/app.json` and `apps/motorsport_hub/main.js` are present.
5. In MGU Store → Settings → Add source, enter the GitHub repository URL.
6. Refresh the source list. The repository may remain Offline if the head unit has no working internet/DNS/GitHub access; fix that connectivity before expecting the catalog to load.

## Important: installable package prerequisite

This source repository is complete as source code, but it does **not** contain the BMW `oap-sdk/` extracted from your specific MGU. The preview-only build succeeds, but it is not an installable `.mgu` package. The normal build needs the SDK from the target head unit, as described in the upstream README. Do not upload an SDK from another vehicle/software version.

## Safety

- xDrive is experimental and disabled by default. The upstream module's supported ECU list, double-confirmation, state checks and read-back limitations remain in force. This does not make every BMW xDrive system compatible.
- Exhaust is disarmed/simulated by default. Real actuation remains subject to upstream adapter matching and arming gates.
- Dyno and drag features are estimates/timing tools; use on a closed course only.
