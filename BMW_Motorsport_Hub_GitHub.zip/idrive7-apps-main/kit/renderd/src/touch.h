#ifndef MGU_TOUCH_H
#define MGU_TOUCH_H
/*
 * Touch routing (touch.c, from IterioDev's mgu-renderd): the centre display's touch PDUs (UDP 30567, the HMI's own input) are diverted here by one
 * nftables rule while an app has claimed screen areas (M_CLAIM). A gesture that starts in a visible app's claim
 * goes to that app (E_TOUCH) and the HMI never sees it; everything else is forwarded to the HMI unchanged.
 */

/* iface: where the display's PDUs arrive (the car: "vlan73", from saddr 160.48.199.115; "lo": a local sender, as in
 * the emulator); saddr may be empty. area x,y,w,h (design px, as apps are told) apps may claim, w 0 = all. Forks the guard: call
 * before the compositor connection. -1 = off. */
int touch_init(const char *iface, const char *saddr, const int area[4]);
/* the divert's table (ip <name>) and ports (in_port, in_port + 1) in place of the defaults; before touch_init.
 * -1 for a bad name or port. */
int touch_ports(int in_port, const char *name);
int touch_fd(void);                  /* the diverted PDUs (poll it), -1 when off */
void touch_read(void);               /* route what came in */
void touch_tick(int claimed);        /* every loop turn: claimed = a visible app has claims -> rule in or out */
void touch_forget(int slot);         /* that app is gone: the rest of its gesture is dropped */
void touch_stop(void);               /* rule out */

/* provided by main.c */
int touch_owner_at(int x, int y);                   /* the client slot claiming design pixel x, y, or -1 */
void touch_send(int slot, int phase, int x, int y); /* E_TOUCH to it (phase 1 down, 2 move, 3 up; design px) */
void touch_outside(void);                           /* a gesture went to the HMI: the claiming apps close */
void touch_unmap(int *x, int *y);                   /* screen px -> the design px apps and claims are in */

#endif
